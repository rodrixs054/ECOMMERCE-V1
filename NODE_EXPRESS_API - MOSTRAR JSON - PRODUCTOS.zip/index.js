//ESTE PROYECTO SERÁ EL QUE CONECTE CON FIREBASE Y NUESTRA PÁGINA WEB
//instalamos npm i cors 


//Con el fin de que se encuentren los puertos de salida por medio del protocolo http
import cors from "cors"


// 1 Importamos la libreria express * npm install --save express * 
import express from 'express';
// 2 - Vamos al json y declaramos despues del main: ** "type": "module", para usar los modulos instalados

import bodyParser from 'body-parser'; // Nos va a permitir tomas los request 

// 3 - Inicializamos la libreria express, la cual es una función 
const app = express()// Nuestra aplicación correra bajo esta variable

// 12 - Importamos lo de users.js
import usersRoute from "./routes/products.js";

// 4 - Delclaramos el puerto en el cual correrá nuestra aplicación:
const PORT = 5000;

// 5 - Inicializamos nuestro bodyParser 
app.use(bodyParser.json()) //Estaremos usando información del JSON en toda nuestra app
//Por medio de objetos de JavaScript para enciar la información al request de la API
app.use(cors())


//13- Nos aseguramos que corra todas las rutas de la carpeta de routes:
//Especificamos el path, para este caso todos van a iniciar con /users
app.use('/productos', usersRoute);

//10 - Debemos especificar las rutas por las cuales nuestra app pueda responder a los request desde un navegdor
//Aquí esperamos los siguiente: -> El path del request para que tome cualquier dirección del navegador
//El segundo parámetro es una callback: (request y response)
app.get('/', (req, res)=>{
    console.log("[TEST]!")

    res.send("Hola desde la página de inicio.")
});


// 6 - Hacemos que nietra app este en escucha constante para preocesar un request 
// Le pasamos el puerto y una función flecha para lograr la conexión
app.listen(PORT, ()=>{
    console.log(`Servidor corriendo en el puerto: http://localhost:${PORT}`) // Salida: Servidor corriendo en el puerto: http://localhost:5000 ** Lo metemos en el navegador

}) // Para probar la conexción usamos: node index.js  (La conexión ha sido éxitosa :D)

// 7 - Instalamos * npm i --save-dev nodemon * para evitar el cerrar y abrir 
// el servidor cada vez que exista un cambio , solo para nuestros propósitos de desarrollo

// 8 - Para correr nuestra app, eliminamos la siguiente línea en el packege.json:
// Objeto de Scripts:  "test": "echo \"Error: no test specified\" && exit 1"
// Y en su lugar colocamos un** "start": "nodemon index.js" ** 

// 9- Guardamos los cambios en el json y corremos nuestras app con ** npm start ** 



