import express from 'express';

//importamos el módulo users.js / controllers
import { createProduct , getProducts, getUser, deleteUser, updateUser} from '../controllers/products.js'; 

// Inicializamos nuestra ruta
const router = express.Router();


//11 - Le decimos el path de lo que es lo que va a visitar
                    //Petición, respuesta
//Todas las rutas comienzan con /users
router.get('/', getProducts);


// 16 - Añadimos la funcionalidad de añadir usuarios a nuestra BD:
//Para ello creamos una nueva ruta para enviar desde el lado del cliente al servidor:

// Le pasamos el path
// A partir de aquí se usar postman para verificar nuestra API para hacer nuestros request:

router.post('/', createProduct);


// 18 - Creamos una nueva ruta:
// El path será /:id // Todo con el fin de asignar un ID único a los usuarios
router.get('/:id', getUser)

// 19 - Creamos ruta para eliminar usuarios por ID:

router.delete('/:id', deleteUser)


// 20 - Ruta para actualizar la información de los usaruarios:
// La actualización de la información se hará por ID

router.patch('/:id', updateUser)

//La exportamos router para que lo lea en el archivo index.js:
export default router;

// 14 Creamos user.json para crear y guardar los diferentes usuarios