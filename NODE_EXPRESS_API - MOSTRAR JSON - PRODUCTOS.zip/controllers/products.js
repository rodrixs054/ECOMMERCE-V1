// Importamos uuid para garantizar que no existan 2 id iguales:
import {v4 as uuidv4} from 'uuid';
// uuidv4 ();Para agregar el ID único para el usuario

//15 - Añadir dos usuarios en nuestro arreglo

//Para poder hacer la conexión de BD
import {collection, getDocs} from "firebase/firestore"

//Importamos nustra BD
import {db} from "../Config/firebase.js"

let users = []

//A que BD nos vamos a conectra y que nombre tiene esa colección
const prodcutCollection = collection(db,"productos")

export const getProducts = async(req, res)=>{
    // Método GET


    const productSnapshot = await getDocs(prodcutCollection);
    const productList = productSnapshot.docs.map(doc => doc.data());

    console.log(productList)
    res.send(productList)

    //console.log(users)

}

export const createProduct = async(req, res)=>{
    //Método POST: 

    const product = req.body

    try {
        const docRef = await addDoc(prodcutCollection, {
            ...product //Lo destructuramos

        });
        res.send("Producto agregado: "+ docRef.id);
        console.log("Producto agregado: " + docRef.id)

      } catch (e) {
        console.error("Error adding document: ", e);

        const productList = docRef.docs.map(doc => doc.data());
        res.send(productList)
        //res.send(`User with the name:  ${user.firstName} has been added to the DATA BASE`)

    }

    //const user = req.body // Devuelve la petición del registro agregado desde postman
    // Afirma que se pudo realizar el insert en la BD

    //Creamos un objeto que traera todo el contenido de user para agregar el id a los
    //Valores existentes en el arreglo de objetos
    //{... user, id: uuidv4()} Esto lo metemos al PUSH 

    // Añadimos lo del JSON al arreglo de users
    //users.push({... user, id: uuidv4()})
    //res.send(`User with the name:  ${user.firstName} has been added to the DATA BASE`)

    //17 - Necesitamos identificar a los usuarios por su id para traer la información relacionada 
    // de un usuario en específico, para ello instalmos uuid con el comando: ** npm i uuid

}

export const getUser = (req, res)=>{
    const {id} = req.params // Obtiene el ID del usuario quien envia la info

    //Se manda la información del usuario para un ID específico
    //Para ello se deberpa encontar el usario en la BD de uusarios 
    //Con el mismo ID:

    const  foundUser = users.find((user)=> user.id === id)

    res.send(foundUser)
}


export const deleteUser = (req, res)=>{

    //

    const {id} = req.params // Obtiene el ID del usuario quien envia la info

    // Si devuelve verdadero no lo borra pero si es falso lo borra
    //user es quien va a verificar el id del usuario con un id específico
    users = users.filter((user)=> user.id !== id);

    res.send(`User with id: ${id}, was deleted from the database`);
}

export const updateUser = (req, res)=>{
    const {id} = req.params // Obtiene el ID del usuario quien envia la info

    //Habilitanos los campos que se pueden cambiar
    const {firstName, lastName, age} = req.body;

    //Encontar el usuario a actualizar:
    const userUpdate = users.find((user) => user.id === id )

    if(firstName){
        //Si el usuario tiene un nombre, entonces:
        userUpdate.firstName  = firstName;
    }

    if(lastName){
        //Si el usuario tiene un apellido, entonces:
        userUpdate.lastName  = lastName;
    }

    if(age){
        //Si el usuario tiene un apellido, entonces:
        userUpdate.age  = age;
    }

    res.send(`User with the ID: ${id}, was updated!`)
}