const x = document.querySelector("#cargarTxt")

const f = document.querySelector("#cargaeJSON")


x.addEventListener("click", obtenerDatos)


function obtenerDatos(){

   // const url = "../data de clase/datos.txt"
    const url = "../data de clase/empleado.json"

    fetch(url).then
    (respuesta =>{
        //console.log(respuesta)
        //return respuesta.text()

        return respuesta.json()
    })
    .then(datos =>{
        console.log(datos)

    }).catch(err => {
        console.log(err)
    })
}