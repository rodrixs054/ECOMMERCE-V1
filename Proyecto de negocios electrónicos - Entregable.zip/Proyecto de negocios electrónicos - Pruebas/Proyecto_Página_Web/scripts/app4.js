//Declaración de padres e hijos para agregar las cards desde la BD
const contenedorCards = document.querySelector(".card-group")
//------------------------------------------------------
//Elemnentos para mostrar el JSON del servidor prodcutos
const vaciarRegistrosJson = document.querySelector("#vaciar-registros")
//console.log(vaciarRegistrosJson)
const verProductos = document.querySelector("#mostrar-registros")

//Contenedor de las cards
const productContent = document.querySelector(".contenedorProductos")

//-------------------------------------------------------------//

console.log(productContent)

//------------------------------------------------------------------


//------------------------------------------------------------------
//Función para cargar en automático las cards de la BD y mostrarlas desde un inicio
document.addEventListener("DOMContentLoaded", cargarProductos, false)


//Para mostrar y ocultar los productos disponibles (Tabla)
vaciarRegistrosJson.addEventListener("click", vaciarJson)
verProductos.addEventListener("click", obtenerInfo)

//Contenedor para mostrar la tabla de productos desde el servidor de productos
const contenedorCarrito2 = document.querySelector("#lista-JSON tbody")
console.log(contenedorCarrito2)


function vaciarJson() {
    tablaDatos.splice(0)
    contenedorCarrito2.innerHTML = ""
}

let tablaDatos = []
//console.log(btnAñadirProducto)

//btnAñadirProducto.addEventListener("click", obtenerInfo)



let nombres
//Obtenemos los datos del servidor.
function obtenerInfo() {
    // const url = "../data de clase/datos.txt"
    const url = "http://localhost:5000/productos"

    fetch(url).then
        (respuesta => {
            //console.log(respuesta)
            //return respuesta.text()

            return respuesta.json()
        })
        .then(datos => {
            //console.log(datos)
            tablaDatos = datos
            //console.log(tablaDatos)
            leerTabla(tablaDatos)
            console.log(tablaDatos)
        }

        ).catch(err => {
            console.log(err)
        })
}

//ESTE PROYECTO CONECTARÁ CON NUESTRA BD EN PRODUCTOS
//Leemos los datos del arreglo tablaDatos y los mostramos en tabla HTML
function leerTabla(datos) {
    tablaDatos.forEach((datos) => {

        const row = document.createElement("tr");
        row.innerHTML = `

            <td>
            <img src = " ${datos.imagen}" width = "80px"/>
           
            </td>

            <td>
                ${datos.nombreProdcuto}
            </td>
            <td>
                ${datos.especificaciones}
            </td>
            <td>
                ${datos.precio}
            </td>
            `;
        contenedorCarrito2.appendChild(row);

    })
    //mostrarProductos()


}

/*
function mostrarProductos(){
    tablaDatos.forEach((datos)=>{
        const cards = document.createElement("div")
        
        cards.classList.add("card")

        
        cards.classList.add("card-body")

        cards.innerHTML=`

        <img src="${datos.imagen}" width="400px" height="400px"/>

        <h5 class='card-title'><b>Peluche de pokemon "${datos.nombreProdcuto}"  </b></h5> 
        <br>
        <h6 class="card-title"><b>Especificaciones de producto:</b></h6>
        
        <p class="card-text">Medidas: ${datos.especificaciones} cm</p>
        <p class="card-text precio1">Precio:<b> $${datos.precio} </b></p>

        <a href="#" class="btn btn-warning description color_btn2 alinear " data-id="3"><b>Añadir producto
            <img src="../icons/icon2.png" />
        </b></a>
                
        `;
        contenedorCards.appendChild(cards)
})
}*/

//Creamos nuestra función para eleminar un prodcuto x en la BD
const deleteProduct = id => db.collection("productos").doc(id).delete();
//Cargamos nuestros productos desde la BD, una vez que la página se carga se muestran las cards
function cargarProductos() {


    db.collection("productos").get().then((querySnapshot) => {
        querySnapshot.forEach((doc) => {

            const pelucheId = doc.id;
            
            console.log(pelucheId)

            const card1 = document.createElement("div")
            card1.classList.add("card-group")

            const card2 = document.createElement("div")
            card2.classList.add("card")
            card2.innerHTML = `<img src="${doc.data().imagen}" class="card-img-top" width="50%" height="50%" alt="50%">
            `
            const card3 = document.createElement("div")
            card3.classList.add("card-body")

            //cards.classList.add("card")

            //cards.classList.add("card-body")

            card3.innerHTML = `
    
            <h5 class='card-title alinear'><b> "${doc.data().nombreProdcuto}"  </b></h5> 
            
            <hr>
            <h6 class="card-title"><b>Especificaciones de producto:</b></h6>
            
            <p class="card-text">Medidas: ${doc.data().especificaciones}</p>
            <p class="card-text precio1">Precio:<b> $${doc.data().precio} </b></p>
            <hr>

            <a href="#" class="btnA btn btn-primary button  alinear  " data-id="${doc.id}"><b>Añadir producto
                <img src="../icons/icon2.png" />
            </b></a>

            <br>
            <div>
                <hr>
                <a  class="btn-delete btn btn-danger button  u-full-wifth flex" data-id="${pelucheId}"><b>Eliminar producto</b></a>
            <div/>       
            `;


            contenedorCards.appendChild(card1)
            card1.appendChild(card2)
            card2.appendChild(card3)





            //console.log(`${doc.id} => ${doc.data().nombreProdcuto}`);



        });
        //Eliminamos un producto de la BD
        const btnDelete = document.querySelectorAll(".btn-delete");
            btnDelete.forEach(btn => {
                btn.addEventListener('click', async(e) => {
                    console.log(e.target.dataset.id)
                    await deleteProduct(e.target.dataset.id)
                    location.reload()
   
                })
            })
            

        



    });
    console.log(contenedorCards.childNodes)
}