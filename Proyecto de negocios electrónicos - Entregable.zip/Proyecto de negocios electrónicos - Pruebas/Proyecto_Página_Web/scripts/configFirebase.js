const firebaseConfig = {
    apiKey: "AIzaSyBXF0zEOI5BWvoAqpDA3rbOShzAwWVqk9M",
    authDomain: "node-express-api-79b60.firebaseapp.com",
    projectId: "node-express-api-79b60",
    storageBucket: "node-express-api-79b60.appspot.com",
    messagingSenderId: "970498986766",
    appId: "1:970498986766:web:5f59a9551b959c3f873d5f"
  };
  
  // Initialize Firebase
firebase.initializeApp(firebaseConfig);

  // Initialize Firebase
const db = firebase.firestore();
