//Formulario para dar de alta productos
//-----------------------------------------------------------
const btnAñadirProducto = document.querySelector("#AñadirProdcuto")
const imagenProducto=document.querySelector("#imagenProducto")

const NombreProducto = document.querySelector("#nombreProducto");

const Medidas = document.querySelector("#descripcion");

const Precio = document.querySelector("#precio");

const card = document.querySelector(".card")

//console.log(btnAñadirProducto)

btnAñadirProducto.addEventListener("click", leerProducto)

let contador= 3 
let contador2= 0

//Función para que lea los campos del formulario y los agregue a la collection "productos"
function leerProducto(e){
    e.preventDefault();

    if( imagenProducto.value !="" & NombreProducto.value != "" & Medidas.value!="" & Precio.value!="" ){
        let mi_card = document.createElement("div"); //Card

        //----------------------------Añadimos los productos a la BD
        db.collection("productos").add({
            imagen: String(imagenProducto.value),
            especificaciones: Medidas.value,
            nombreProdcuto: NombreProducto.value,
            precio: Number(precio.value)
        })
        .then((docRef) => {
            alert("Producto agregado satisfactoriamente");
            location.reload()
        })
        .catch((error) => {
            console.error("Error adding document: ", error);
        });
        //-----------------------------------------------
        
        
        console.log(NombreProducto.value)
        console.log(Medidas.value)
        console.log(Precio.value)
        
        
    }else{
        alert("Debes de llenar los campos para agregar el producto")
    }
    
    
}

