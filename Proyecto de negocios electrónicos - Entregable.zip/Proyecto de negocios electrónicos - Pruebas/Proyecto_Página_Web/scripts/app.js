const carrito = document.querySelector("#carrito")

const  contenedorCarrito= document.querySelector("#lista-carrito tbody")

const  vaciar_CarritoBTN= document.querySelector("#vaciar-carrito")

const listaProductos = document.querySelector('.card-group')

/*-----------------------------------*/
const TotalCompra = document.querySelector('.pago')
/*-----------------------------------*/
console.log(TotalCompra)
let articulosCarrito = []

console.log(listaProductos)

//Borrar un peluche en específico
carrito.addEventListener("click",eliminarPeluche)

function eliminarPeluche(e){
    if(e.target.classList.contains('borrar-producto')){
        const pelucheId = e.target.getAttribute('data-id')

        //console.log(PelucheId)

       articulosCarrito = articulosCarrito.filter(peluche=> peluche.id !== pelucheId)

       AgregarCarritoHTML();
    }
}

//------------- Vaciamos el carrito de compras por completo ----------------//
vaciar_CarritoBTN.addEventListener('click', eliminar_productos)

function eliminar_productos(){
    
    if(articulosCarrito!=""){
            //Eliminamos 
        articulosCarrito.splice(0)
        contenedorCarrito.innerHTML=""

        alert("Se han eliminado los artículos de tu carrito")
        console.log(articulosCarrito)
        console.log(contenedorCarrito)


        //Cambiamos la perspectiva de cuando se eliminan los objetos del carrito
        rowCompra = TotalCompra
        rowCompra.innerHTML=`<h6><b>Añade productos para tu total de compra.</b></h6>`


    }else{
        alert("Carrito vacio, agrega elementos para eliminarlos")
    }

}
//------------- Vaciamos el carrito de compras por completo ----------------//


listaProductos.addEventListener('click',agregarPeluche)

function agregarPeluche(e){
    e.preventDefault();
    if(e.target.classList.contains("btnA")){
        console.log("Click en agregar producto")
        //console.log(e.target.parentElement.parentElement)
        const producto_seleccionado = e.target.parentElement.parentElement;
        //console.log("El producto seleccionado es:" + producto_seleccionado)
        leerDatosProducto(producto_seleccionado)
        
       
    }
}

function leerDatosProducto(producto){
    console.log(producto)

    let total_A_Pagar=0
    const infoproducto = {
        imagen:producto.querySelector("img").src,
        titulo:producto.querySelector("h5 b").textContent,
        precio: Number(producto.querySelector(".precio1 b").textContent.replace("$","")),
        id:producto.querySelector("a").getAttribute("data-id"),
        cantidad:Number(1),

        /*--------------------------- */
        totalCompra:{
            totalProducto:Number(0),

        }
        

    }

    //console.log("El id del prodcuto agregado es: " + infoproducto.id)
    const existe = articulosCarrito.some(peluche=> peluche.id === infoproducto.id)
    console.log(existe)

    if(existe){
        
        //------------Aumentamos en 1 la cantidad del producto ------------------------//    
        for(let i = 0; i<articulosCarrito.length;i++){
        
            articulosCarrito[i].id
            if(articulosCarrito[i].id== infoproducto.id){
                articulosCarrito[i].cantidad++
                /*-----------------------------------------------------*/
                articulosCarrito[i].totalCompra.totalProducto = articulosCarrito[i].precio * articulosCarrito[i].cantidad

            }
        }
        //------------Aumentamos en 1 la cantidad del producto ------------------------//
        //articulosCarrito.some(peluche=> peluche.cantidad += infoproducto.cantidad)
        /*
            LÓGICA DEL PPROFESOR:
            const peluche = articulosCarrito.map(peluche=>{
                if(peluche.id === infoprodcuto.id){
                    peluche.cantidad++
                    return peluche
                }else{
                    return 
                }
            })
        */
    }else{

        articulosCarrito =[...articulosCarrito, infoproducto]
    }


    /*------------------------------------------------------------------------------ */

    for(let i = 0; i<articulosCarrito.length;i++){
        total_A_Pagar += articulosCarrito[i].totalCompra.totalProducto 
        
    }console.log(total_A_Pagar)

    //Añadimos o sumamos todos los valores de los precios de los productos y lo guardamos en total_A_Pagar
    rowCompra = TotalCompra
    rowCompra.innerHTML=`<h6><b>Total a pagar de la compra: $${total_A_Pagar} </b></h6>`
    /*---------------------------------------------------------------------------------- */

    console.log(articulosCarrito)
    AgregarCarritoHTML()
}





function AgregarCarritoHTML(){
    // Liampiamos la lista antes de recorrer la lista de objetos
    //contenedorCarrito.innerHTML=""
    
    // La otra forma de limpiar el carrito para que no se repitan los elementos
    while(contenedorCarrito.firstChild){
        contenedorCarrito.removeChild(contenedorCarrito.firstChild)
    }

    articulosCarrito.forEach(peluche =>{
       
        row = document.createElement("tr")
        row.innerHTML = `
    
            <td>
                <img src = "${peluche.imagen}" width = "80px"/>
            </td>

            <td class="centrar">
            ${peluche.titulo}
            </td>

            <td class="centrar">
            $${peluche.precio}
            </td>
                 
            <td class="centrar">
            ${peluche.cantidad}
            </td>

            <td>
                <a href ="#" class = "borrar-producto" data-id="${peluche.id}">BORRAR</a>
            </td>


            <br>
            <td class = "centrar">
            $${peluche.totalCompra.totalProducto}
            </td>

            `
        contenedorCarrito.appendChild(row)



    })   

    console.log("El arrglo del carrito de compras es: " + articulosCarrito)

    db.collection("carrito").add({
        articulosCarrito
    })
    .then((docRef) => {
        console.log("Producto agregado satisfactoriamente");
        //location.reload()
    })
    .catch((error) => {
        console.error("Error adding document: ", error);
    });

}

