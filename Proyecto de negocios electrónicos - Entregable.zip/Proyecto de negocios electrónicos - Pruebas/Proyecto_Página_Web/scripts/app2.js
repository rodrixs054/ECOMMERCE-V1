//Función del botón flotante para subir al comienzo de la página web
const btnFlotante = document.querySelector('.up-button')

btnFlotante.addEventListener("click", moverInicio)

console.log(btnFlotante)

function moverInicio(){
   
    window.scrollTo({
        top:0,
        behavior:"smooth"
    })
}